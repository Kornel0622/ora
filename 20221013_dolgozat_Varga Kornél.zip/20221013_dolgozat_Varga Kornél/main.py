from feladat import *
from functions import*


print(f'A versenyen {resztvettek()} versenyző indult! ')
print(f'{legalabb()} versenyző ért el legalább 8600 pontot!')
print(f'A győztes pontszáma:Warner Damien {gyoztesPont()} pontos eredmennyel!')