names = ['BASTIEN Steven', 'dos SANTOS Felipe', 'DUBLER Cedric', 'ERM Johannes', 'HELCELET Adam Sebastian', 
         'KAZMIREK Kai', 'LEPAGE Pierce', 'MAYER Kevin', 'MOLONEY Ashley', 'ROE Martin', 'SCANTLING Garrett', 
         'SHKURENYOV Ilya', 'SYKORA Jiri', 'TILGA Karel', 'UIBO Maicel', 'URENA Jorge', 'VICTOR Lindon', 
         'WARNER Damian', 'WIESIOLEK Pawel', 'ZHUK Vitaliy', 'ZIEMEK Zachery' ]
points = [8236, 7880, 7008, 8213, 8004, 8126, 8604, 8726, 8649, 7863, 8611, 8413, 7943, 7018, 8037,
          8322, 8414, 9018, 8176, 8131, 8435] 

# A 2021-es olimpián tízpróbában a names listában felsorolt versenyzők indultak. Elért eredményeiket a points lista tartalmazza.
# Oldja meg az alábbi feladatokat!

# Írja ki a képernyőre, hogy a 2021-es olimpián hány atléta teljesített a 10 próbát!

# Írja ki a képernyőre, hány olyan versenyző volt, aki legalább 8600 pontot ért el!

# Írja ki a képernyőre a versenyzők pontszámának az átlagát!

# Írja ki a képrnyőre a győztes versenyző nevét és pontszámát!

# Kérje be a felhasználótól egy versenyző nevét és írja ki pontszámát!
# Ha nem találja, írja ki, hogy a versenyző nem indult a versenyen!