from itertools import count
from data import *

def osszesvizsgazo():
    count = 0
    nevek > 0
    if nevek in range:
        len(nevek)
    return count