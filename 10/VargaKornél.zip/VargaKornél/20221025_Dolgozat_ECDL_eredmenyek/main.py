from data import *
from functions import osszesvizsgazo

print(f'{len(nevek)} vizsgázó van összesen')
