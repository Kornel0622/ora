'''
1. Hány vizsgázó adata van az állományban?
2. Hányan tettek sikeres vizsgát (75% vagy felette)?
3. Mi a legrosszabb eredmény?
4. Írja ki, hogy kik érték el a legrosszabb eredményt?
5. Kérjen be egy nevet, írja ki, hogy hány százalékot ért el a tanuló! Ha nincs ilyen tanuló akkor írja ki, hogy "Nincs ilyen tanuló!"
'''